import React from 'react';
import {NavigationContainer} from '@react-navigation/native';

import AuthNavigator from './app/navigation/AuthNavigator';
import TabNavigator from './app/navigation/TabNavigator';


export default function App() {
  return (
    <NavigationContainer>
      <AuthNavigator/>
    </NavigationContainer>
  );
}


// //testing individual screens
// import { StatusBar } from 'expo-status-bar';
// import React from 'react';
// import { StyleSheet, Text, View } from 'react-native';
// import AccountScreen from './app/screens/AccountScreen';
// import MyDestinationScreen from './app/screens/MyDestinationScreen';
// import MyTravelScreen from './app/screens/MyTravelScreen';
// import NewTravelScreen from './app/screens/NewTravelScreen';
// import WelcomeScreen from './app/screens/WelcomeScreen';
// import TabNavigator from './app/navigation/TabNavigator';

// export default function App() {
//   return (
//     <View style={styles.container}>
//         <AccountScreen/>
//     </View>
//   );
// }

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
    
//   },
// });

