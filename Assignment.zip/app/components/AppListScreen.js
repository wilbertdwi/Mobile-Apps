import React from 'react';
import { View, StyleSheet, Image, TouchableHighlight } from 'react-native';

import AppText from '../components/AppText';

//similar to applistitem but it cannot be swiped
function AppListScreen({image, title, subtitle, IconComponent}) {
    return (
            <View style={styles.container}>
                {IconComponent}
                {image && <Image source={image} style={styles.image}/>}
                <View style={styles.textContainer}>
                    <AppText style={styles.title}>{title}</AppText>
                    {subtitle && <AppText style={styles.subtitle}>{subtitle}</AppText>}
                </View>
            </View>
    );
}

const styles = StyleSheet.create({
    container:{
        flexDirection:'row',
        padding:5,
        paddingRight:100,
    },

    image:{
        height:60,
        width:60,
        borderRadius:37,
        marginTop:5,
        marginBottom:10,
        marginRight:20,
        marginLeft:10,
    },

    textContainer:{
        flexDirection:'column',
    },

    title:{
        fontSize:20,
        fontWeight:"bold",
    },

    subtitle:{
        fontSize:16,
    },
})

export default AppListScreen;