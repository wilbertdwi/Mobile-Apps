import React from 'react';
import { StyleSheet, TextInput, View } from 'react-native';
import {MaterialCommunityIcons} from '@expo/vector-icons';

import AppColors from '../config/AppColors';
//use to enter anything that can be typed in
function AppTextInput({icon, ...otherProps}) {
    return (
        <View style={styles.container}>
            {icon && <MaterialCommunityIcons name={icon} size={30}/>}
            <TextInput style={styles.textInput}{...otherProps}/>
        </View>
    );
}

const styles = StyleSheet.create({
    container:{
        backgroundColor:AppColors.white,
        flexDirection:'row',
        borderRadius: 25,
        padding:10, 
        marginVertical:10,
        width:'100%',
    },
    textInput:{
        fontSize:20,
        color:AppColors.black,
        fontFamily: Platform.OS === 'android' ? "Roboto" : "Arial",
        marginLeft: 10,
        flex:1,
    }
})
export default AppTextInput;