import React from 'react';
import { Text, TouchableOpacity, View, StyleSheet } from 'react-native';

import AppColors from '../config/AppColors';

function AppButton({title, color="primaryColor", onPress}) {
    return (
        <TouchableOpacity onPress={onPress}>
            <View style={[styles.button,{backgroundColor:AppColors[color]} ]}>
                <Text style={styles.text}>{title}</Text>
            </View>
        </TouchableOpacity>
    );
}

const styles = StyleSheet.create({
    button:{
        marginTop:5,
        backgroundColor: AppColors.primaryColor,
        borderRadius:20,
        padding:15,
        justifyContent:'center',
        alignItems:'center',
        width:'100%',
    },

    text:{
        color:AppColors.white,
        fontSize:24,
    },
})

export default AppButton;