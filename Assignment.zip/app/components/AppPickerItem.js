import React from 'react';
import { TouchableOpacity, StyleSheet } from 'react-native';
import AppText from './AppText';
import AppIcon from './AppIcon';

function AppPickerItem({onPress, label, icon}) {
    return (
        <TouchableOpacity onPress={onPress} style={styles.container}>
            <AppIcon name={icon}/>
            <AppText>{label}</AppText>
        </TouchableOpacity>
    );
}
const styles = StyleSheet.create({
    container:{
        padding:10,
        justifyContent:"center",
        flexDirection:"row",
    }
})

export default AppPickerItem;