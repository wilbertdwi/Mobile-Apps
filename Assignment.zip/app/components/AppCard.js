import React from 'react';
import { View, Image, StyleSheet} from 'react-native';

import AppColors from '../config/AppColors';
import AppText from './AppText';

//creates a card with image, title and subtitle.
function AppCard({category,title, subtitle, image}) {
    return (
            <View style={styles.container}>
                {isFinite(image)?<Image source={image} style={styles.image}/> :<Image source={{uri: image}} style={styles.image}/>}
                <AppText style={styles.title}>{title}</AppText>
                <AppText style={styles.subtitle}>{subtitle}</AppText>
                <AppText style={styles.subtitle}>{category}</AppText>
             </View>
    );
}

const styles = StyleSheet.create({
    container:{
        backgroundColor:AppColors.teal,
        borderRadius:20,
        overflow:"hidden",
        marginBottom:20,
    },

    image:{
        height:250,
        width:"100%",
    },

    title:{
        fontWeight:"bold",

    },

    subtitle:{
        fontSize:14,
    },
})

export default AppCard;