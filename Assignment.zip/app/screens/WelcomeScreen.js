import React from 'react';
import { ImageBackground, StyleSheet, Platform, View, Image } from 'react-native';

import AppButton from '../components/AppButton';
import AppScreen from '../components/AppScreen';

const blurRadiusValue = Platform.OS === 'android'? 0.7:5.5;

function WelcomeScreen({navigation}) {
    return (
        <AppScreen>
            <ImageBackground 
                source={require("../assets/travel_background.jpg")}
                style={styles.background}
                blurRadius={blurRadiusValue}>
                    
                <View style={styles.welcomeContainer}>
                    <Image style={styles.logo} source={require('../assets/travel_logo_2.png')}></Image>
                </View>

                <View style={styles.buttonContainer}>
                    <AppButton title="Login" color="secondaryColor" onPress={()=> navigation.navigate("Login")}/>
                    <AppButton title="Register" color="secondaryColor" onPress={()=> navigation.navigate("Register")}/>
                </View>
            </ImageBackground>
        </AppScreen>
       
    );
}

const styles = StyleSheet.create({
    background:{
        flex:1,
    },

    welcomeContainer:{
        justifyContent:'center',
        alignItems:'center',
        marginTop:100,
    },

    logo:{
        height:250,
        width:250,
        marginBottom:10,
    },

    buttonContainer:{
        marginTop:50,
        flexDirection:'column',
        justifyContent:'space-between',
        height: 150,
        alignSelf:'center',
        width: '50%',
    }
})

export default WelcomeScreen;