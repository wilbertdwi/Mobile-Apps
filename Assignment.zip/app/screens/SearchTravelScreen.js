import React from 'react';
import { View, StyleSheet, FlatList } from 'react-native';

import AppScreen from '../components/AppScreen';
import AppColors from '../config/AppColors';
import AppListScreen from '../components/AppListScreen';
import AppText from '../components/AppText';
//list of all recommended travel destinations
const destination = [
    {id:1, name:"Four Seasons Hotel Sydney", location:"199 George St, Sydney NSW 2000", image: require("../assets/../assets/hotel1.jpg")},
    {id:2, name:"The Victoria Hotel", location:"176A Young St, Annandale NSW 2038", image: require("../assets/hotel2.jpg")},
    {id:3, name:"Bondi Beach", location:"Bondi Beach, NSW 2026", image: require("../assets/beach1.jpg")},
    {id:4, name:"Manly Beach", location:"Manly Beach, NSW", image: require("../assets/beach2.jpg")},
    {id:5, name:"Sydney Opera House", location:"Bennelong Point, Sydney NSW 2000", image: require("../assets/spots1.jpg")},
    {id:6, name:"Luna Park", location:"1 Olympic Dr, Milsons Point NSW 2061", image: require("../assets/spots2.jpg")},
    {id:7, name:"Cafe Sydney", location:"5 Sydney Customs House, 31 Alfred St, Sydney NSW 2000", image: require("../assets/restaurant1.jpg")},
    {id:8, name:"Mr Wong", location:"3 Bridge Ln, Sydney NSW 2000", image: require("../assets/restaurant2.jpg")},
]

function SearchTravelScreen(props) {
    return (
        <AppScreen style={styles.container}>
            <View style={styles.search}>
                <AppText>Search Recommendations</AppText>
            </View>
            <FlatList 
            data = {destination} 
            keyExtractor = {author => author.id.toString()}
            renderItem = {({item}) => 
                <AppListScreen 
                    title={item.name}
                    image={item.image}
                    subtitle={item.location}
                    onPress={() => console.log(item)}
                />}
            ItemSeparatorComponent = { () => 
                <View style={styles.seperator}/>
            }
            />
        </AppScreen>
    );
}

const styles = StyleSheet.create({
    search:{
        height:80,
        backgroundColor:AppColors.teal,
        justifyContent:"center",
        alignItems:'center',
    },
    container:{
        backgroundColor:AppColors.secondaryColor,
        flex:1,
    },
    seperator:{
        width:"100%",
        height:2,
        backgroundColor:AppColors.lightpink,
    },
})
export default SearchTravelScreen;