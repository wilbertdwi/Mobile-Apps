import React from 'react';
import { View, StyleSheet, Image } from 'react-native';
import {Formik} from 'formik';
import * as Yup from 'yup';

import AppTextInput from '../components/AppTextInput';
import AppScreen from '../components/AppScreen';
import AppColors from '../config/AppColors';
import AppButton from '../components/AppButton';
import AppText from '../components/AppText';
import DataManager from '../config/DataManager';

const schema = Yup.object().shape(
    {
        username:Yup.string().required().min(2).max(20).label("Username"),
        email:Yup.string().required().email().label("Email"),
        password: Yup.string().required().min(4).max(10).label("Password"),
    }
);


function RegisterScreen({navigation, props}) {
   
    return (
        <AppScreen style={styles.container}>
            <View style={styles.welcomeContainer}>
                <Image style={styles.logo} source={require('../assets/travel_logo.png')}></Image>
            </View>
            <Formik initialValues={{username:'', email:'',password:'',}}
                onSubmit = {(values) => {
                    let arrayData = DataManager.getInstance();
                    const idOfUser = arrayData.getSizeOfUserArray();

                const newUser = {//new users created will have a default picture of user1 and sent to data manager
                            id: idOfUser,
                            name: values.username,
                            email: values.email,
                            password: values.password,
                            image: require('../assets/user1.png'),
                        };
                        arrayData.addUsers(newUser);
                        navigation.navigate("Login"); 
                 }}
                validationSchema={schema}>
                {({handleChange, handleSubmit, errors, setFieldTouched, touched})=>(
                <>
                    <View style={styles.textInputContainer}>
                    <AppTextInput 
                        icon="account" 
                        placeholder="Enter Your New Username" 
                        autoCapitalize='none' 
                        autoCorrect={false} 
                        onBlur ={() => setFieldTouched("username")} 
                        onChangeText={handleChange("username")}
                    />
                    {touched.username && <AppText style={{color:"red", fontSize:12}}>{errors.username}</AppText>}
                    <AppTextInput 
                        icon="email" 
                        placeholder="Enter Your New Email Address" 
                        autoCapitalize='none' 
                        autoCorrect={false} 
                        keyboardType="email-address" 
                        onBlur ={() => setFieldTouched("email")} 
                        onChangeText={handleChange("email")}
                    />
                    {touched.email && <AppText style={{color:"red", fontSize:12}}>{errors.email}</AppText>}
                    <AppTextInput 
                        icon="lock" 
                        placeholder="Enter Your New Password" 
                        autoCapitalize='none' 
                        autoCorrect={false} 
                        onBlur ={() => setFieldTouched("password")} 
                        secureTextEntry 
                        onChangeText={handleChange("password")}
                    />
                    {touched.password && <AppText style={{color:"red", fontSize:12}}>{errors.password}</AppText>}
                    </View>
                    <AppButton title="Register" onPress={handleSubmit}/>
                </>
                )}
            </Formik> 
        </AppScreen>
    );
}

const styles = StyleSheet.create({
    container:{
        flex:1,
        backgroundColor:AppColors.secondaryColor,
        marginTop:0,
        padding:25,
    },

    welcomeContainer:{
        justifyContent:'center',
        alignItems:'center',
        marginTop:25,
    },

    logo:{
        height:100,
        width:100,
        marginBottom:10,
    },

    textInputContainer:{
        marginTop:75,
        marginVertical:50,
    },
})
export default RegisterScreen;