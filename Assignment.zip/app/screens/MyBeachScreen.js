import React from 'react';
import {StyleSheet, FlatList, View } from 'react-native';

import AppCard from '../components/AppCard';
import AppScreen from '../components/AppScreen';
import AppColors from '../config/AppColors';
import AppIcon from '../components/AppIcon';
import DataManager from '../config/DataManager';

const getBeaches = () =>{
    let commonData = DataManager.getInstance();
    let user = commonData.getUserID();
    return commonData.getBeaches(user);
}
//beach travels only
function MyBeachScreen(props) {
    const beachList = getBeaches();
    return (
        <AppScreen style={styles.container}>

            <FlatList
            data={beachList}
            keyExtractor= {beach => beach.beachid.toString()}
            renderItem = {({item}) => 
                <AppCard
                title={item.title}
                subtitle={item.subtitle}
                image={item.image}
                />}
            />
        </AppScreen>
    );
}
const styles = StyleSheet.create({
    container:{
        flex:1,
        padding:20,
        backgroundColor:AppColors.secondaryColor,
        marginTop:0,
    },
    deleteView:{
        backgroundColor:AppColors.primaryColor,
        width:95,
        justifyContent:"center",
        alignItems:"center",
    }
})
export default MyBeachScreen;