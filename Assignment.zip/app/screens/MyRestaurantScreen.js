import React from 'react';
import {StyleSheet, FlatList, View } from 'react-native';

import AppCard from '../components/AppCard';
import AppScreen from '../components/AppScreen';
import AppColors from '../config/AppColors';
import AppIcon from '../components/AppIcon';
import DataManager from '../config/DataManager';

const getRestaurants = () =>{
    let commonData = DataManager.getInstance();
    let user = commonData.getUserID();
    return commonData.getRestaurants(user);
}
//restaurant plans only
function MyRestaurantScreen(props) {
    const restaurantList = getRestaurants();
    return (
        <AppScreen style={styles.container}>

            <FlatList
            data={restaurantList}
            keyExtractor= {restaurant => restaurant.restaurantid.toString()}
            renderItem = {({item}) => 
                <AppCard
                title={item.title}
                subtitle={item.subtitle}
                image={item.image}
                />}
            />
        </AppScreen>
    );
}
const styles = StyleSheet.create({
    container:{
        flex:1,
        padding:20,
        backgroundColor:AppColors.secondaryColor,
        marginTop:0,
    },
    deleteView:{
        backgroundColor:AppColors.primaryColor,
        width:95,
        justifyContent:"center",
        alignItems:"center",
    }
})
export default MyRestaurantScreen;