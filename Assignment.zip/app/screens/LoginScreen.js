import React from 'react';
import { View, StyleSheet, Image } from 'react-native';
import {Formik} from 'formik';
import * as Yup from 'yup';

import AppTextInput from '../components/AppTextInput';
import AppScreen from '../components/AppScreen';
import AppColors from '../config/AppColors';
import AppButton from '../components/AppButton';
import AppText from '../components/AppText';
import DataManager from '../config/DataManager';

const schema = Yup.object().shape(
    {
        email:Yup.string().required().email().label("Email"),
        password: Yup.string().required().min(4).max(10).label("Password"),
    }
);


const validateUser = ({email, password}) => {
    return(
        DataManager.getInstance().users.filter((user) => user.email === email && user.password === password).length>0
    );
};

const getUser = ({email}) => {
    return DataManager.getInstance().users.find((user) => user.email === email);
}

const createUser = ({email}) => {
    let commonData= DataManager.getInstance();
    let userID = getUser({email}).id;
    commonData.setUserID(userID);
}

function LoginScreen({navigation}) {

    return (
        <AppScreen style={styles.container}>
            <View style={styles.welcomeContainer}>
                <Image style={styles.logo} source={require('../assets/travel_logo.png')}></Image>
            </View>
            <Formik 
                initialValues={{email:'',password:'',}}
                onSubmit = {(values, {resetForm}) => {
                    if(validateUser(values)){
                        console.log(values);
                        resetForm();
                        DataManager.getInstance.userID=getUser(values).id;//get username and password from data manager
                        createUser(values);
                        navigation.navigate("Account", {
                            screen:"Account",
                            params:{
                                screen:"Account",
                                params:{
                                    paramEmail:values.email,
                                    paramName: getUser(values).name,
                                    paramImage: getUser(values).image,
                                },
                            }
                        }
                        );
                    }
                    else{
                        resetForm();
                        alert("Invalid Login Details");
                    }
                 }}
                validationSchema={schema}>
                {({values, handleChange, handleSubmit, errors, setFieldTouched, touched})=>(
                <>
                    <View style={styles.textInputContainer}>
                    <AppTextInput 
                        icon="email" 
                        placeholder="Enter Your Email Address" 
                        autoCapitalize='none' 
                        autoCorrect={false} 
                        keyboardType="email-address" 
                        value={values.email} 
                        onBlur ={() => setFieldTouched("email")} 
                        onChangeText={handleChange("email")}
                    />
                    {touched.email && <AppText style={{color:"red", fontSize:18}}>{errors.email}</AppText>}
                    <AppTextInput 
                        icon="lock" 
                        placeholder="Enter Your Password" 
                        autoCapitalize='none' 
                        autoCorrect={false} 
                        value={values.password} 
                        onBlur ={() => setFieldTouched("password")} 
                        secureTextEntry 
                        onChangeText={handleChange("password")}
                    />
                    {touched.password && <AppText style={{color:"red", fontSize:18}}>{errors.password}</AppText>}
                    </View>
                    <AppButton title="Login" onPress={handleSubmit}/>
                </>
            )}
            </Formik>
        </AppScreen>

        

    );
}

const styles = StyleSheet.create({
    container:{
        flex:1,
        backgroundColor:AppColors.secondaryColor,
        marginTop:0,
        padding:25,
    },

    welcomeContainer:{
        justifyContent:'center',
        alignItems:'center',
        marginTop:25,
    },

    logo:{
        height:100,
        width:100,
        marginBottom:10,
    },

    textInputContainer:{
        marginTop:75,
        marginVertical:50,
    },
})

export default LoginScreen;