import React, {useState} from 'react';
import { TouchableOpacity, StyleSheet, Image } from 'react-native';

import AppButton from '../components/AppButton';
import AppPicker from '../components/AppPicker';
import AppScreen from '../components/AppScreen';
import AppText from '../components/AppText';
import AppTextInput from '../components/AppTextInput';
import * as ImagePicker from 'expo-image-picker';
import AppColors from '../config/AppColors';
import DataManager from '../config/DataManager';
import AppIcon from '../components/AppIcon';

const categories = [
    {label: "Hotels", value:1, icon:"bed"},
    {label: "Beaches", value:2, icon:"beach"},
    {label: "Tourist Spots", value:3, icon:"bank"},
    {label: "Restaurants", value:4, icon:"silverware"},
];


function NewTravelScreen({navigation}) {
    const[title, setTitle] = useState("");
    const[subtitle, setSubtitle] = useState("");
    const[image, setImage] = useState(null);
    const[category, setCategory] = useState("");

    const[titleError, setTitleError] = useState("");
    const[subtitleError, setSubtitleError] = useState("");
    const[imageError, setImageError]=useState("");
    const[categoryError, setCategoryError] = useState("");

    let openImagePickerAsync = async () => {
        let permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();

        if (permissionResult.granted === false) {
        alert("Permission to access camera roll is required!");
        return;
        }

        let pickerResult = await ImagePicker.launchImageLibraryAsync();


        if (pickerResult.cancelled === true) {
            return;
        }
        setImage({path: pickerResult.uri});
        console.log(pickerResult);
    }

    const doErrorCheck = () => {
        setTitleError(title.length>0 ? "": "Please set a valid place");
        setSubtitleError(subtitle.length>0 ? "": "Please set a location");
        setCategoryError(category? "": "Please set a category");
        setImageError(image? "": "Please pick an image");
        return ((title.length>0) && (subtitle.length>0) && (category) && (image)? true: false)
    }
    //add hotel plans
    const addHotel = () => {
        
        let DataArr = DataManager.getInstance();
        let user = DataArr.getUserID();
        let hotelID = DataArr.Hotelslength()+2;

        const newHotel ={
            userid: user,
            hotelid: hotelID, 
            title: title,
            subtitle: subtitle,
            image: image.path,
        };
        DataArr.addHotels(newHotel);
    }
    //add beach plans
    const addBeach = () => {
        let DataArr = DataManager.getInstance();
        let user = DataArr.getUserID();
        let beachID = DataArr.Beachslength()+2;
        const newBeach ={
            userid: user,
            beachid: beachID, 
            title: title,
            subtitle: subtitle,
            image: image.path,
        };
        DataArr.addBeach(newBeach);
    }
    //add tourist spots plans
    const addSpots = () => {
        let DataArr = DataManager.getInstance();
        let user = DataArr.getUserID();
        let spotsID = DataArr.Spotslength()+2;
        const newSpots ={
            userid: user,
            spotsid: spotsID, 
            title: title,
            subtitle: subtitle,
            image: image.path,
        };
        DataArr.addSpots(newSpots);
    }
    //add restaurant plans
    const addRestaurant = () => {
        let DataArr = DataManager.getInstance();
        let user = DataArr.getUserID();
        let restaurantID = DataArr.Restaurantslength()+2;
        const newRestaurant ={
            userid: user,
            restaurantid: restaurantID, 
            title: title,
            subtitle: subtitle,
            image: image.path,
        };
        DataArr.addRestaurants(newRestaurant);
  
    }
    return (
        <AppScreen style={{backgroundColor:AppColors.secondaryColor}}>
            <AppTextInput
                icon="domain"
                placeholder="Enter the name of the place"
                value={title}
                onChangeText={(inputText) => setTitle(inputText)}
            />
            {titleError.length>0 ? <AppText style={{color:"red", fontSize:18}}>{titleError}</AppText>:<></>}
            <AppTextInput
                icon="map-marker"
                placeholder="Enter the address"
                value={subtitle}
                onChangeText={(inputText) => setSubtitle(inputText)}
            />
            {subtitleError.length>0 ? <AppText style={{color:"red", fontSize:18}}>{subtitleError}</AppText>:<></>}
            <AppPicker
                selectedItem = {category}
                onSelectItem = {item => setCategory(item)}
                data={categories} 
                icon="apps" 
                placeholder="All Destinations"
            />
            {categoryError.length>0 ? <AppText style={{color:"red", fontSize:18}}>{categoryError}</AppText>:<></>}

            <TouchableOpacity style={styles.imageButton} onPress={openImagePickerAsync}>
                 <AppIcon name="camera" size={80} iconColor={AppColors.secondaryColor} backgroundColor={AppColors.white}/>
                 {image && <Image source={{uri: image.path}} style={{height:80, width:80, marginLeft: 20,}}/>}
            </TouchableOpacity>
            {imageError.length>0 ? <AppText style={{margin:5, color:"red", fontSize:16}}>{imageError}</AppText>: <></>}

            <AppButton title="Add Destination" onPress={() => 
                { 
                    if(doErrorCheck()){ // if category picked is the same as category value, then add details to that screen/travel plan
                        console.log(category.value);

                        if(category.value === 1){
                            addHotel();
                            navigation.navigate("Hotels");
                        }
                        else if(category.value === 2){
                            addBeach();
                            navigation.navigate("Beaches");
                        }
                        else if(category.value === 3){
                            addSpots();
                            navigation.navigate("Tourist Spots");
                        }
                        else if(category.value === 4){
                            addRestaurant();
                            navigation.navigate("Restaurants");
                        }
                        
                    }
                 }}/>
        </AppScreen>
    );
}

const styles = StyleSheet.create({
    imageButton:{
        justifyContent:"center",
        alignItems:"center",
        flexDirection:"row",
        marginBottom: 30,
    }
})

export default NewTravelScreen;