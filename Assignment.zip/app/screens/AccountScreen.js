import React from 'react';
import { View, StyleSheet, Image} from 'react-native';

import AppScreen from '../components/AppScreen';
import AppColors from '../config/AppColors';
import AppListItem from '../components/AppListItem';
import AppIcon from '../components/AppIcon';


function AccountScreen({navigation, route}) {
    return (
        <AppScreen style={styles.container}>
            <View style={styles.welcomeContainer}>
                <Image style={styles.logo} source={require('../assets/travel_picture.png')}></Image>
            </View>
            <View style={styles.profileContainer}>
                <AppListItem image={route.params.paramImage} title={route.params.paramName} subtitle={route.params.paramEmail}/>
            </View>
            <View style={styles.linksContainer}>
                <AppListItem title="Hotels" IconComponent={<AppIcon name="bed" size={50} iconColor={AppColors.azure} backgroundColor={AppColors.primaryColor}/>} onPress={() => navigation.navigate("Hotels")}/>
                <AppListItem title="Beaches" IconComponent={<AppIcon name="beach" size={50} iconColor={AppColors.azure} backgroundColor={AppColors.primaryColor}/>} onPress={() => navigation.navigate("Beaches")}/>
                <AppListItem title="Tourist Spots" IconComponent={<AppIcon name="bank" size={50} iconColor={AppColors.azure} backgroundColor={AppColors.primaryColor}/>} onPress={() => navigation.navigate("Tourist Spots")}/>
                <AppListItem title="Restaurants" IconComponent={<AppIcon name="silverware" size={50} iconColor={AppColors.azure} backgroundColor={AppColors.primaryColor}/>} onPress={() => navigation.navigate("Restaurants")}/>
            </View>
        </AppScreen>
        
    );
}

const styles = StyleSheet.create({
    container:{
        backgroundColor:AppColors.secondaryColor,
    },

    welcomeContainer:{
        justifyContent:'center',
        alignItems:'center',
        marginTop:25,
    },

    profileContainer:{
        marginTop: 50,
        height:90,
        backgroundColor:AppColors.teal,
        justifyContent:"center",

    },

    logo:{
        height:100,
        width:300,
        marginBottom:10,
    },
    linksContainer:{
        marginVertical:50,
        backgroundColor:AppColors.teal,
        height:370,
        justifyContent:"space-around",
        paddingLeft:10,
    }
})

export default AccountScreen;