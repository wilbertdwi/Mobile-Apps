import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

import NewTravelScreen from '../screens/NewTravelScreen';
import AppColors from '../config/AppColors';
import AppIcon from '../components/AppIcon';
import WelcomeScreen from '../screens/WelcomeScreen';
import AccountNavigator from './AccountNavigator';
import SearchTravelScreen from '../screens/SearchTravelScreen';

const AppTab = createBottomTabNavigator();

const TabNavigator = () => (
  <AppTab.Navigator tabBarOptions={{activeTintColor:AppColors.lightpink, activeBackgroundColor:AppColors.teal}}>
    <AppTab.Screen name ="Account" component={AccountNavigator} options={{tabBarIcon: () => <AppIcon size={24} name="home" backgroundColor={AppColors.primaryColor}/>}}/>
    <AppTab.Screen name ="Search Travels" component={SearchTravelScreen} options={{tabBarIcon: () => <AppIcon size={24} name="magnify" backgroundColor={AppColors.primaryColor}/>}}/>
    <AppTab.Screen name ="Add Travels" component={NewTravelScreen} options={{tabBarIcon: () => <AppIcon size={24} name="plus" backgroundColor={AppColors.primaryColor}/>}}/>
    <AppTab.Screen name ="Logout" component={WelcomeScreen} options={{tabBarIcon: () => <AppIcon size={24} name="exit-to-app" backgroundColor={AppColors.primaryColor}/> ,tabBarVisible:false}}/>
  </AppTab.Navigator>
)

export default TabNavigator;