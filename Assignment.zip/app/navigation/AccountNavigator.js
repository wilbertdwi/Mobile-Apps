import React from 'react';

import {createStackNavigator} from '@react-navigation/stack';

import AccountScreen from '../screens/AccountScreen';
import MyHotelScreen from '../screens/MyHotelScreen';
import MyTouristSpotScreen from '../screens/MyTouristSpotScreen';
import MyBeachScreen from '../screens/MyBeachScreen';
import MyRestaurantScreen from '../screens/MyRestaurantScreen';

const AppStack = createStackNavigator();

const AccountNavigator = () => (
    <AppStack.Navigator mode="modal">
        <AppStack.Screen name ="Account" component={AccountScreen} options={{headerShown:false}}/>
        <AppStack.Screen name ="Hotels" component={MyHotelScreen}/>
        <AppStack.Screen name ="Beaches" component={MyBeachScreen}/>
        <AppStack.Screen name ="Tourist Spots" component={MyTouristSpotScreen}/>
        <AppStack.Screen name ="Restaurants" component={MyRestaurantScreen}/>
    </AppStack.Navigator>
)

export default AccountNavigator;