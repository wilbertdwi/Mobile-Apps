export default{
    black: '#000000',
    white:'#ffffff',
    primaryColor: '#0092b7',
    secondaryColor:'#0a708a',
    teal:'#15bdb0',
    lightpink:"#fe757c",
    azure:'#f0ffff',
}