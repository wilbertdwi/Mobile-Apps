export default class DataManager {
    static myInstance = null;
    userID = "";

    users = [
        {
            id:"user1",
            name:"Bob Robert",
            email:"be@gmail.com",
            password:"12345",
            image:require('../assets/user1.png'),
        },
        {
            id:"user2",
            name:"Jon Wu",
            email:"jonwu@gmail.com",
            password:"45678",
            image:require('../assets/user2.png'),
        },
    ];
    

    hotels = [
        {
            userid: "user1",
            hotelid:1,
            title:"Four Seasons Hotel Sydney",
            subtitle:"199 George St, Sydney NSW 2000",
            image:require("../assets/hotel1.jpg"),
        },

        {
            userid: "user1",
            hotelid:2,
            title:"The Victoria Hotel",
            subtitle:"176A Young St, Annandale NSW 2038",
            image:require("../assets/hotel2.jpg"),
        },

        {
            userid: "user2",
            hotelid:1,
            title:"Four Seasons Hotel Sydney",
            subtitle:"199 George St, Sydney NSW 2000",
            image:require("../assets/hotel1.jpg"),
        }
    ]

    beaches = [
        {
            userid: "user1",
            beachid:1,
            title:"Bondi Beach",
            subtitle:"Bondi Beach, NSW 2026",
            image:require("../assets/beach1.jpg"),
        },
        {
            userid: "user2",
            beachid:2,
            title:"Manly Beach",
            subtitle:"Manly Beach, NSW",
            image:require("../assets/beach2.jpg"),
        },
    ]

    spots =[
        {
            userid: "user1",
            spotsid:1,
            title:"Sydney Opera House",
            subtitle:"Bennelong Point, Sydney NSW 2000",
            image:require("../assets/spots1.jpg"),
        },
        {
            userid: "user2",
            spotsid:2,
            title:"Luna Park",
            subtitle:"1 Olympic Dr, Milsons Point NSW 2061",
            image:require("../assets/spots2.jpg"),
        },
    ]

    restaurants=[
        {
            userid: "user1",
            restaurantid:1,
            title:"Cafe Sydney",
            subtitle:"5 Sydney Customs House, 31 Alfred St, Sydney NSW 2000",
            image:require("../assets/restaurant1.jpg"),
        },
        {
            userid: "user2",
            restaurantid:2,
            title:"Mr Wong",
            subtitle:"3 Bridge Ln, Sydney NSW 2000",
            image:require("../assets/restaurant2.jpg"),
        }
    ]

    static getInstance(){
        if(DataManager.myInstance==null){
            DataManager.myInstance = new DataManager();
        }
        return this.myInstance;
    }

    getUserID(){
        return this.userID;
    }

    setUserID(id){
        this.userID = id;
    }

    getHotels(id){
        return this.hotels.filter((hotel) => hotel.userid === id);
    }

    getRestaurants(id){
        return this.restaurants.filter((restaurant) => restaurant.userid === id);
    }

    getBeaches(id){
        return this.beaches.filter((beach) => beach.userid === id);
    }

    getTouristSpots(id){
        return this.spots.filter((spot) => spot.userid === id);
    }

    addHotels(hotel){
        this.hotels.push(hotel);
    }
    addBeach(beach){
        this.beaches.push(beach);
    }
    addRestaurants(restaurant){
        this.restaurants.push(restaurant);
    }
    addSpots(spot){
        this.spots.push(spot);
    }

    Hotelslength(){
        return this.hotels.length;
    }
    Beachslength(){
        return this.beaches.length;
    }

    Restaurantslength(){
        return this.restaurants.length;
    }

    Spotslength(){
        return this.spots.length;
    }

    addUsers(user){
        this.users.push(user);
    }

    getSizeOfUserArray(){
        this.users.length;
    }

}