import React from 'react';
import renderer from "react-test-renderer";
import AppCard from './components/AppCard';
import AppText from './components/AppText';
import AppColors from './config/AppColors';

test("trivially true", ()=> {
    expect(1).toBe(1);
});

test("AppText will render with correct font and styling", ()=>{
    const json = renderer.create(<AppText/>).toJSON();
    expect(json.props.style[0].fontSize).toBe(28);
    expect(json.props.style[0].fontFamily).toBe("Arial");
});

test("AppText contains text", ()=> {
    const json = renderer.create(<AppText>Fantastic</AppText>).toJSON();
    expect(json.props.style[0].fontSize).toBe(28);
    expect(json.props.style[0].fontFamily).toBe("Arial");
    expect(json.children.includes("Fantastic"));
});

test("AppCard will render with correct style", ()=> {
    const json = renderer.create(<AppCard/>).toJSON();
    //container
    expect(json.props.style.backgroundColor).toBe(AppColors.teal);
    expect(json.props.style.borderRadius).toBe(20);
    expect(json.props.style.overflow).toBe('hidden');
    expect(json.props.style.marginBottom).toBe(20);
    //image
    expect(json.children[0].props.style.height).toBe(250);
    expect(json.children[0].props.style.width).toBe('100%');
    expect(json).toMatchSnapshot();
});

test("AppCard will render with correct text and snapshot", ()=> {
    const json = renderer.create(<AppCard title="Bondi Beach" subtitle="Bondi Beach, NSW 2026" image={require("./assets/beach1.jpg")}/>).toJSON();
    expect(json.children.includes('Bondi Beach'));
    expect(json.children.includes('Bondi Beach, NSW 2026'));
    expect(json).toMatchSnapshot();
});

